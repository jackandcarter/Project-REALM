-- MySQL dump 10.13  Distrib 8.2.0, for macos13.5 (x86_64)
--
-- Host: localhost    Database: World_server
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Armor`
--

DROP TABLE IF EXISTS `Armor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Armor` (
  `ArmorID` int NOT NULL,
  `SlotType` varchar(50) NOT NULL,
  `Health` int DEFAULT NULL,
  `Attack` int DEFAULT NULL,
  `Defense` int DEFAULT NULL,
  `Agility` int DEFAULT NULL,
  `Luck` int DEFAULT NULL,
  `Stamina` int DEFAULT NULL,
  `Mana` int DEFAULT NULL,
  `Rage` int DEFAULT NULL,
  `CriticalHitRate` int DEFAULT NULL,
  `BlackMagic` int DEFAULT NULL,
  `GreenMagic` int DEFAULT NULL,
  `WhiteMagic` int DEFAULT NULL,
  `Regeneration` int DEFAULT NULL,
  `Construction` int DEFAULT NULL,
  `Rarity` varchar(50) NOT NULL,
  `ValueAmount` int DEFAULT NULL,
  `LevelRequired` int DEFAULT NULL,
  `ClassRequired` int DEFAULT NULL,
  `EnchantmentType` varchar(50) DEFAULT NULL,
  `ArmorDescription` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ArmorID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Armor`
--

LOCK TABLES `Armor` WRITE;
/*!40000 ALTER TABLE `Armor` DISABLE KEYS */;
/*!40000 ALTER TABLE `Armor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BuildingMaterials`
--

DROP TABLE IF EXISTS `BuildingMaterials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BuildingMaterials` (
  `MaterialID` int NOT NULL,
  `MaterialName` varchar(255) NOT NULL,
  `MaterialType` varchar(50) NOT NULL,
  `MaxStackAmount` int NOT NULL,
  `RequiredLevel` int NOT NULL,
  `PlacementType` varchar(50) NOT NULL,
  `CanBeUsedIndoors` tinyint(1) DEFAULT NULL,
  `CanBeUsedOutdoors` tinyint(1) DEFAULT NULL,
  `MaterialDescription` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`MaterialID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BuildingMaterials`
--

LOCK TABLES `BuildingMaterials` WRITE;
/*!40000 ALTER TABLE `BuildingMaterials` DISABLE KEYS */;
/*!40000 ALTER TABLE `BuildingMaterials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Items`
--

DROP TABLE IF EXISTS `Items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Items` (
  `ItemID` int NOT NULL,
  `ItemName` varchar(255) NOT NULL,
  `ItemType` varchar(50) NOT NULL,
  `MaxStackAmount` int NOT NULL,
  PRIMARY KEY (`ItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Items`
--

LOCK TABLES `Items` WRITE;
/*!40000 ALTER TABLE `Items` DISABLE KEYS */;
/*!40000 ALTER TABLE `Items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LevelProgression`
--

DROP TABLE IF EXISTS `LevelProgression`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LevelProgression` (
  `Level` int NOT NULL,
  `ExperienceRequirement` int DEFAULT NULL,
  PRIMARY KEY (`Level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LevelProgression`
--

LOCK TABLES `LevelProgression` WRITE;
/*!40000 ALTER TABLE `LevelProgression` DISABLE KEYS */;
/*!40000 ALTER TABLE `LevelProgression` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Spells`
--

DROP TABLE IF EXISTS `Spells`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Spells` (
  `SpellID` int NOT NULL,
  `SpellName` varchar(255) NOT NULL,
  `BaseDamage` int DEFAULT NULL,
  `BaseHealAmount` int DEFAULT NULL,
  `SpellType` varchar(50) NOT NULL,
  `SpellDescription` varchar(255) DEFAULT NULL,
  `RequiredClass` int DEFAULT NULL,
  `UnlockLevel` int DEFAULT NULL,
  `BaseCastTime` int DEFAULT NULL,
  `DoTBaseAmount` int DEFAULT NULL,
  `HoTBaseAmount` int DEFAULT NULL,
  PRIMARY KEY (`SpellID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Spells`
--

LOCK TABLES `Spells` WRITE;
/*!40000 ALTER TABLE `Spells` DISABLE KEYS */;
/*!40000 ALTER TABLE `Spells` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'World_server'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-12 13:02:45
