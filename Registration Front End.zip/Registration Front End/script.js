function registerUser() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Make a request to the authentication server for user registration
    fetch('http://localhost:5000/create_user_account?username=' + username + '&password=' + password, {
        method: 'GET'
    })
    .then(response => response.text())
    .then(data => {
        alert(data); // Display the response (you can handle it better)
    })
    .catch(error => {
        console.error('Error:', error);
    });
}
