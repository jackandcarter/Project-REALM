// LoginManager.cs
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using System.Collections;

public class LoginManager : MonoBehaviour
{
    public GameObject loginPanel;
    public InputField usernameInput;
    public InputField passwordInput;
    public Button connectButton;

    public GameObject realmListPanel;
    public Transform realmListContainer;
    public GameObject realmListItemPrefab;
    public Button continueButton;

    private string authServerURL = "http://localhost:5000/authenticate";
    private string realmServerURL = "http://localhost:5001";

    private string selectedRealm;

    void Start()
    {
        connectButton.onClick.AddListener(ConnectButtonClicked);
        continueButton.onClick.AddListener(ContinueButtonClicked);

        loginPanel.SetActive(true);
        realmListPanel.SetActive(false);
    }

    void ConnectButtonClicked()
    {
        StartCoroutine(AuthenticateUser());
    }

    IEnumerator AuthenticateUser()
    {
        if (string.IsNullOrEmpty(usernameInput.text) || string.IsNullOrEmpty(passwordInput.text))
        {
            Debug.Log("Please enter username and password.");
            yield break;
        }

        WWWForm form = new WWWForm();
        form.AddField("username", usernameInput.text);
        form.AddField("password", passwordInput.text);

        using (UnityWebRequest www = UnityWebRequest.Post(authServerURL, form))
        {
            yield return www.SendWebRequest();

            if (www.result == UnityWebRequest.Result.Success)
            {
                Debug.Log("Authentication successful!");
                loginPanel.SetActive(false);
                realmListPanel.SetActive(true);

                StartCoroutine(GetRealms());
            }
            else
            {
                Debug.Log("Authentication failed. Please check your credentials.");
            }
        }
    }

    IEnumerator GetRealms()
    {
        UnityWebRequest realmRequest = UnityWebRequest.Get(realmServerURL + "/get_realms");
        yield return realmRequest.SendWebRequest();

        if (realmRequest.result == UnityWebRequest.Result.Success)
        {
            string realmsJson = realmRequest.downloadHandler.text;
            RealmInfo[] realms = JsonUtility.FromJson<RealmInfo[]>(realmsJson);

            foreach (Transform child in realmListContainer)
            {
                Destroy(child.gameObject);
            }

            foreach (RealmInfo realm in realms)
            {
                GameObject realmItem = Instantiate(realmListItemPrefab, realmListContainer);
                RealmListItem realmListItem = realmItem.GetComponent<RealmListItem>();
                realmListItem.SetRealmInfo(realm, this); // Pass the LoginManager reference
            }
        }
        else
        {
            Debug.Log("Failed to retrieve realm list.");
        }
    }

    void ContinueButtonClicked()
    {
        if (!string.IsNullOrEmpty(selectedRealm))
        {
            Debug.Log("Continue button clicked. Transition to Character Selection Scene for realm: " + selectedRealm);
            // TODO: Transition to the Character Selection Scene and pass the selectedRealm
        }
        else
        {
            Debug.Log("Please select a realm before continuing.");
        }
    }

    public void OnRealmSelected(string realmName)
    {
        // Handle the selected realm
        selectedRealm = realmName;
        Debug.Log("Realm selected: " + selectedRealm);
    }

    [System.Serializable]
    public class RealmInfo
    {
        public string name;
        public string type;
        public int connected_users;
        public int character_count;
    }
}
