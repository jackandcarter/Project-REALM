using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Slot : MonoBehaviour, IDropHandler
{
    public Image icon;

    [Tooltip("Specify the required item tag for this slot.")]
    public string requiredItemTag;

    private EquipmentItem currentItem; // The item in this slot

    public delegate void ItemEquippedHandler(EquipmentItem item);
    public event ItemEquippedHandler OnItemEquipped;

    public delegate void ItemRemovedHandler(EquipmentItem item);
    public event ItemRemovedHandler OnItemRemoved;

    public void OnDrop(PointerEventData eventData)
    {
        // Handle item drop logic
        GameObject draggedItem = eventData.pointerDrag;
        if (draggedItem != null && CheckItemTags(draggedItem))
        {
            EquipItem(draggedItem.GetComponent<EquipmentItem>());
        }
    }

    private bool CheckItemTags(GameObject item)
    {
        // Check if the item has the correct tag for this slot
        return item.CompareTag(requiredItemTag);
    }

    public void EquipItem(EquipmentItem newItem)
    {
        currentItem = newItem;

        // Update the displayed item image
        UpdateItemDisplay();

        // Notify the ArmoryManager to equip the item and apply its stats
        ArmoryManager.Instance.EquipItem(newItem);

        // Trigger the OnItemEquipped event
        OnItemEquipped?.Invoke(newItem);
    }

    private void UpdateItemDisplay()
    {
        // Update the displayed item image
        if (icon != null)
        {
            Sprite itemSprite = currentItem.GetComponent<SpriteRenderer>().sprite;
            icon.sprite = itemSprite;
            icon.enabled = true;
        }
    }

    public void ClearSlot()
    {
        // Notify the ArmoryManager to remove the item and its stats
        ArmoryManager.Instance.RemoveItemStats(currentItem);

        currentItem = null;

        // Clear the displayed item image
        if (icon != null)
        {
            icon.sprite = null;
            icon.enabled = false;
        }

        // Trigger the OnItemRemoved event
        OnItemRemoved?.Invoke(currentItem);
    }

    public EquipmentItem GetItem()
    {
        return currentItem;
    }
}
