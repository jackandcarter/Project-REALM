using UnityEngine;

public class BuildingPlacement : MonoBehaviour
{
    // Example prefab to instantiate
    public GameObject buildingPrefab;

    // Set to true when in building mode
    private bool isBuilding = false;

    // Snap grid size
    public float gridSize = 1.0f;

    // Update is called once per frame
    void Update()
    {
        if (isBuilding)
        {
            // Raycast to determine where the player wants to build
            if (Input.GetMouseButtonDown(0))
            {
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                RaycastHit hit;

                if (Physics.Raycast(ray, out hit))
                {
                    // Check if the hit point is on the building plane
                    if (hit.collider.gameObject == this.gameObject)
                    {
                        // Snap the hit point to the grid
                        Vector3 snappedPoint = SnapToGrid(hit.point);

                        // Instantiate the building prefab at the snapped point
                        Instantiate(buildingPrefab, snappedPoint, Quaternion.identity);
                    }
                }
            }
        }
    }

    // Toggle building mode
    public void ToggleBuildingMode(bool enable)
    {
        isBuilding = enable;
    }

    // Function to snap a point to the grid
    private Vector3 SnapToGrid(Vector3 point)
    {
        float snappedX = Mathf.Floor(point.x / gridSize) * gridSize + gridSize / 2;
        float snappedY = Mathf.Floor(point.y / gridSize) * gridSize + gridSize / 2;
        float snappedZ = Mathf.Floor(point.z / gridSize) * gridSize + gridSize / 2;

        return new Vector3(snappedX, snappedY, snappedZ);
    }
}
