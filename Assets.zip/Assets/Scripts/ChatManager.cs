using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.EventSystems;

public class ChatManager : MonoBehaviour, IDragHandler
{
    public Text chatLogText;
    public InputField chatInputField;
    public ScrollRect chatScrollRect;
    public RectTransform chatWindow;

    private string playerName = "PlayerName";
    private string currentChannel = "/say";

    private string worldServerURL = "http://localhost:5002";

    private List<ChatMessage> chatMessages = new List<ChatMessage>();

    void Start()
    {
        StartCoroutine(ConnectToServer());
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Return) && !string.IsNullOrEmpty(chatInputField.text))
        {
            SendMessageToServer(chatInputField.text);
            chatInputField.text = string.Empty;
        }
    }

    IEnumerator ConnectToServer()
    {
        UnityWebRequest connectRequest = UnityWebRequest.Get(worldServerURL + "/connect");
        yield return connectRequest.SendWebRequest();

        if (connectRequest.result == UnityWebRequest.Result.Success)
        {
            Debug.Log("Connected to World Server");
            StartCoroutine(GetChatMessages());
        }
        else
        {
            Debug.LogError("Failed to connect to World Server");
        }
    }

    IEnumerator GetChatMessages()
    {
        while (true)
        {
            UnityWebRequest chatRequest = UnityWebRequest.Get(worldServerURL + "/chat");
            yield return chatRequest.SendWebRequest();

            if (chatRequest.result == UnityWebRequest.Result.Success)
            {
                string chatMessagesJson = chatRequest.downloadHandler.text;
                List<ChatMessage> newMessages = JsonUtility.FromJson<List<ChatMessage>>(chatMessagesJson);

                chatMessages.AddRange(newMessages);

                if (chatMessages.Count > 200)
                    chatMessages.RemoveRange(0, chatMessages.Count - 200);

                DisplayChatMessages(chatMessages);
            }
            else
            {
                Debug.LogError("Failed to retrieve chat messages");
            }

            yield return new WaitForSeconds(1.0f);
        }
    }

    void SendMessageToServer(string message)
    {
        WWWForm form = new WWWForm();
        form.AddField("character_name", playerName);
        form.AddField("channel", currentChannel);
        form.AddField("message", message);

        UnityWebRequest sendRequest = UnityWebRequest.Post(worldServerURL + "/send_message", form);
        sendRequest.SendWebRequest();
    }

    void DisplayChatMessages(List<ChatMessage> messages)
    {
        List<string> formattedMessages = new List<string>();

        foreach (var msg in messages)
        {
            formattedMessages.Add(msg.ToString());
        }

        chatLogText.text = string.Join("\n", formattedMessages);
        Canvas.ForceUpdateCanvases();
        chatScrollRect.verticalNormalizedPosition = 0f;
    }

    public void OnDrag(PointerEventData eventData)
    {
        // Implement resizing logic here
        chatWindow.sizeDelta += new Vector2(eventData.delta.x, -eventData.delta.y);
    }

    [System.Serializable]
    public class ChatMessage
    {
        public string sender;
        public string channel;
        public string message;

        public override string ToString()
        {
            return $"<color=yellow>{sender}</color> <color=cyan>({channel})</color>: {message}";
        }
    }
}
