using UnityEngine;
using UnityEngine.UI;

public class ClassManager : MonoBehaviour
{
    public static ClassManager Instance;

    [Header("Class Switching")]
    public ClassData[] classDataArray; // Use ClassData Scriptable Objects for each class
    private int currentClassIndex = 0;

    [Header("Transformation")]
    public GameObject transformationEffect;

    [Header("UI Elements")]
    public Image classIconImage;
    public Text classNameText;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        SwitchClass(currentClassIndex);
    }

    public void SwitchClass(int newIndex)
    {
        // Ensure the new index is within the array bounds
        if (newIndex >= 0 && newIndex < classDataArray.Length)
        {
            // Deactivate any specific elements related to the current class
            DeactivateCurrentClass();

            // Update the current class index
            currentClassIndex = newIndex;

            // Activate any specific elements related to the new class
            ActivateNewClass();

            // No class-specific bonuses to apply
        }
        else
        {
            Debug.LogError("Invalid class index.");
        }
    }

    private void DeactivateCurrentClass()
    {
        // Implement any deactivation logic for the current class if needed
        // For example, you can deactivate UI elements or specific game objects
    }

    private void ActivateNewClass()
    {
        // Implement any activation logic for the new class if needed
        // For example, you can activate UI elements or specific game objects

        // Update UI elements with the information of the new class
        classIconImage.sprite = classDataArray[currentClassIndex].classIcon;
        classNameText.text = classDataArray[currentClassIndex].className;
    }

    public void StartTransformation()
    {
        if (transformationEffect != null)
        {
            Instantiate(transformationEffect, transform.position, Quaternion.identity);
        }

        Invoke("CompleteTransformation", 3f);
    }

    private void CompleteTransformation()
    {
        // Handle any logic after the transformation is complete
    }
}
