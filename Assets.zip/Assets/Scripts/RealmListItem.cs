// RealmListItem.cs
using UnityEngine;
using UnityEngine.UI;

public class RealmListItem : MonoBehaviour
{
    public Text realmNameText;
    public Text realmTypeText;
    public Text connectedUsersText;
    public Text characterCountText;

    private LoginManager loginManager; // Added reference to LoginManager

    public void SetRealmInfo(LoginManager.RealmInfo realmInfo, LoginManager loginManager) // Updated method signature
    {
        realmNameText.text = realmInfo.name;
        realmTypeText.text = "Type: " + realmInfo.type;
        connectedUsersText.text = "Connected Users: " + realmInfo.connected_users;
        characterCountText.text = "Character Count: " + realmInfo.character_count;

        // Store the reference to LoginManager
        this.loginManager = loginManager;
    }

    public void OnRealmItemClick()
    {
        // Notify LoginManager when the realm item is clicked
        if (loginManager != null)
        {
            loginManager.OnRealmSelected(realmNameText.text);
        }
    }
}
