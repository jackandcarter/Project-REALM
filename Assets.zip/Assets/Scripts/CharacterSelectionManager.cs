using UnityEngine;
using UnityEngine.UI;

public class CharacterSelectionManager : MonoBehaviour
{
    public GameObject characterListPanel;
    public Transform characterListContainer;
    public GameObject characterListItemPrefab;
    public Button createCharacterButton;
    public Button enterWorldButton;

    private string selectedRealm;
    private string selectedCharacter;

    // Initialize the character selection scene
    void Start()
    {
        // Assuming createCharacterButton and enterWorldButton are connected to their respective buttons in the inspector
        createCharacterButton.onClick.AddListener(CreateCharacterButtonClicked);
        enterWorldButton.onClick.AddListener(EnterWorldButtonClicked);

        // Assume selectedRealm is set when transitioning from the login manager
        selectedRealm = "Realm1"; // Replace with actual selected realm

        // Populate character list based on the selected realm
        PopulateCharacterList();
    }

    // Handle the "Create Character" button click
    void CreateCharacterButtonClicked()
    {
        // TODO: Implement logic for creating a new character
        Debug.Log("Create Character button clicked.");
    }

    // Handle the "Enter World" button click
    void EnterWorldButtonClicked()
    {
        if (!string.IsNullOrEmpty(selectedCharacter))
        {
            // TODO: Transition to the Game World scene with the selected character
            Debug.Log("Enter World button clicked. Transition to Game World with character: " + selectedCharacter);
        }
        else
        {
            Debug.Log("Please select a character before entering the world.");
        }
    }

    // Populate the character list based on the selected realm
    void PopulateCharacterList()
    {
        // TODO: Retrieve character data for the selected realm from the server
        // Sample data for testing
        string[] characters = { "Character1", "Character2", "Character3" };

        // Clear existing items
        foreach (Transform child in characterListContainer)
        {
            Destroy(child.gameObject);
        }

        // Populate character list
        foreach (string character in characters)
        {
            GameObject characterItem = Instantiate(characterListItemPrefab, characterListContainer);
            CharacterListItem characterListItem = characterItem.GetComponent<CharacterListItem>();
            characterListItem.SetCharacterInfo(character, this); // Pass the CharacterSelectionManager reference
        }
    }

    // Update the selected character when a character is clicked in the list
    public void OnCharacterSelected(string characterName)
    {
        selectedCharacter = characterName;
        Debug.Log("Character selected: " + selectedCharacter);
    }
}
