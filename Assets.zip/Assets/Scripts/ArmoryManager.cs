using UnityEngine;

public class ArmoryManager : MonoBehaviour
{
    public static ArmoryManager Instance;

    // Reference to the player's equipment slots
    public Slot[] equipmentSlots;

    // Player's current base stats
    private int currentHealth;
    private int currentAttack;
    private int currentDefense;
    private int currentAgility;
    private int currentLuck;
    private int currentStamina;
    private int currentCriticalHitRate;
    private int currentBlackMagic;
    private int currentGreenMagic;
    private int currentWhiteMagic;
    private int currentRegeneration;
    private int currentConstruction;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void EquipItem(EquipmentItem item)
    {
        // Apply the additional stats from the equipped item
        ApplyAdditionalStats(item);

        // Trigger the OnItemEquipped event for each slot
        foreach (Slot slot in equipmentSlots)
        {
            if (slot.requiredItemTag == item.itemTag)
            {
                slot.EquipItem(item);
            }
        }
    }

    private void ApplyAdditionalStats(EquipmentItem item)
    {
        // Apply the additional stats from the equipped item
        currentHealth += item.additionalHealth;
        currentAttack += item.additionalAttack;
        currentDefense += item.additionalDefense;
        currentAgility += item.additionalAgility;
        currentLuck += item.additionalLuck;
        currentStamina += item.additionalStamina;
        currentCriticalHitRate += item.additionalCriticalHitRate;
        currentBlackMagic += item.additionalBlackMagic;
        currentGreenMagic += item.additionalGreenMagic;
        currentWhiteMagic += item.additionalWhiteMagic;
        currentRegeneration += item.additionalRegeneration;
        currentConstruction += item.additionalConstruction;
    }

    public void RemoveItemStats(EquipmentItem item)
    {
        // Remove the additional stats from the unequipped item
        currentHealth -= item.additionalHealth;
        currentAttack -= item.additionalAttack;
        currentDefense -= item.additionalDefense;
        currentAgility -= item.additionalAgility;
        currentLuck -= item.additionalLuck;
        currentStamina -= item.additionalStamina;
        currentCriticalHitRate -= item.additionalCriticalHitRate;
        currentBlackMagic -= item.additionalBlackMagic;
        currentGreenMagic -= item.additionalGreenMagic;
        currentWhiteMagic -= item.additionalWhiteMagic;
        currentRegeneration -= item.additionalRegeneration;
        currentConstruction -= item.additionalConstruction;

        // Trigger the OnItemRemoved event for each slot
        foreach (Slot slot in equipmentSlots)
        {
            if (slot.requiredItemTag == item.itemTag)
            {
                slot.ClearSlot();
            }
        }
    }

    // Implement other necessary methods or events based on your game's requirements
}
