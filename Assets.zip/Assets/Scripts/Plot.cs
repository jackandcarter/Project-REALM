using UnityEngine;

public class Plot : MonoBehaviour
{
    // Adjust these variables in the inspector
    public bool enableScaffolding = true;
    public GameObject scaffoldingPrefab;

    public float heightLimit = 10.0f; // Maximum height from the plot's floor level

    private void Start()
    {
        // Spawn scaffolding based on neighboring plots
        UpdateScaffolding();
    }

    // Function to update scaffolding based on neighboring plots
    public void UpdateScaffolding()
    {
        if (enableScaffolding && scaffoldingPrefab != null)
        {
            // Remove existing scaffolding
            RemoveScaffolding();

            // Check neighboring plots and spawn scaffolding on unconnected edges
            CheckAndSpawnScaffolding(Vector3.forward);
            CheckAndSpawnScaffolding(Vector3.back);
            CheckAndSpawnScaffolding(Vector3.right);
            CheckAndSpawnScaffolding(Vector3.left);
        }
    }

    // Function to remove existing scaffolding
    private void RemoveScaffolding()
    {
        GameObject[] existingScaffolding = GameObject.FindGameObjectsWithTag("Scaffolding");
        foreach (GameObject scaffold in existingScaffolding)
        {
            Destroy(scaffold);
        }
    }

    // Function to check and spawn scaffolding on a specific edge
    private void CheckAndSpawnScaffolding(Vector3 direction)
    {
        RaycastHit hit;
        if (!Physics.Raycast(transform.position, direction, out hit, 1.0f))
        {
            Vector3 spawnPosition = transform.position + direction * 0.5f;
            Instantiate(scaffoldingPrefab, spawnPosition, Quaternion.identity);
        }
    }

    // Function to check if the height limit is exceeded
    public bool CanPlaceAtHeight(Vector3 position, float objectHeight)
    {
        float distanceFromBottom = position.y - transform.position.y;
        return distanceFromBottom + objectHeight <= heightLimit;
    }
}
