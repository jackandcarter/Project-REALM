using UnityEngine;
using UnityEngine.UI;

public class CharacterListItem : MonoBehaviour
{
    public Text characterNameText;
    private CharacterSelectionManager characterSelectionManager;

    // Set character information for the list item
    public void SetCharacterInfo(string characterName, CharacterSelectionManager manager)
    {
        characterSelectionManager = manager;
        characterNameText.text = characterName;
    }

    // Handle the click event when a character is selected
    public void OnItemClick()
    {
        if (characterSelectionManager != null)
        {
            characterSelectionManager.OnCharacterSelected(characterNameText.text);
        }
    }
}
