using UnityEngine;

[CreateAssetMenu(fileName = "NewSkillData", menuName = "Game/SkillData")]
public class SkillData : ScriptableObject
{
    public string skillName;
    public int skillDamage;
    public float skillCastTime; // In seconds

    [Header("Skill Type")]
    public SkillType skillType;

    [Header("Target Type")]
    public TargetType targetType;

    [Header("Effect")]
    public bool isBuff;
    public bool isDebuff;
    public bool isHealOverTime;
    public int effectDuration; // In seconds
    public int effectAmount;

    // Add more skill-related fields as needed

    public enum SkillType
    {
        SingleTargetDamage,
        AreaOfEffectDamage,
        SingleTargetHeal,
        AreaOfEffectHeal,
        Buff,
        Debuff
        // Add more types as needed
    }

    public enum TargetType
    {
        Self,
        SingleEnemy,
        MultipleEnemies,
        SinglePartyMember,
        MultiplePartyMembers
        // Add more types as needed
    }
}
