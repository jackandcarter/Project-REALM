using UnityEngine;

public class EquipmentItem : MonoBehaviour
{
    [Header("Additional Stats")]
    public int additionalHealth;
    public int additionalAttack;
    public int additionalDefense;
    public int additionalAgility;
    public int additionalLuck;
    public int additionalStamina;
    public int additionalCriticalHitRate;
    public int additionalBlackMagic;
    public int additionalGreenMagic;
    public int additionalWhiteMagic;
    public int additionalRegeneration;
    public int additionalConstruction;

    [Header("Item Details")]
    public string itemName;
    public string itemTag; // Tag to identify the item for slot matching

    // Add more properties as needed
}
