using UnityEngine;

[CreateAssetMenu(fileName = "NewClassData", menuName = "Game/ClassData")]
public class ClassData : ScriptableObject
{
    public string className;
    public Sprite classIcon;

    [Header("Base Stats")]
    public int baseHealth;
    public int baseAttack;
    public int baseDefense;
    public int baseAgility;
    public int baseLuck;
    public int baseStamina;
    public int baseCriticalHitRate;
    public int baseBlackMagic;
    public int baseGreenMagic;
    public int baseWhiteMagic;
    public int baseRegeneration;
    public int baseConstruction;
    // Add more stats as needed

    [Header("Skills")]
    public SkillData[] skills;

    [Header("Starting Gear")]
    public EquipmentItem startingWeapon;
    public EquipmentItem startingHeadgear;
    public EquipmentItem startingNecklace;
    public EquipmentItem startingWristguard;
    public EquipmentItem startingChestplate;
    public EquipmentItem startingLeggings;
    public EquipmentItem startingBoots;
    public EquipmentItem startingArms;
    public EquipmentItem startingHands;
    public EquipmentItem startingRing1;
    public EquipmentItem startingRing2;
    public EquipmentItem startingOffHand;
    // Add more starting gear as needed
}
