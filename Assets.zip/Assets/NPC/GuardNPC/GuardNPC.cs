using System.Collections;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;

public class GuardNPC : MonoBehaviour
{
    [Header("Sensory Properties")]
    public float viewDistance = 15f;
    public float viewAngle = 60f;
    public float hearingRange = 10f;
    public LayerMask visionLayerMask;
    public LayerMask hearingLayerMask;

    [Header("Guard Properties")]
    public float health = 100f;
    public float chaseRange = 10f;
    public float attackRange = 2f;
    public float attackDamage = 10f;
    public float attackRate = 1f;
    public string enemyTag = "Enemy";
    public Transform guardPost;

    [Header("Guard Equipment")]
    public GameObject weaponPrefab;
    public GameObject armorPrefab;

    [Header("Dialogue System")]
    public string[] dialogues;
    public AudioClip[] voiceLines;
    public GameObject dialogueTextPrefab;
    public Transform dialogueSpawnPoint;
    public Canvas worldCanvas;
    public Vector3 floatingTextOffset = new Vector3(0, 2f, 0);
    public float floatUpDistance = 1f;
    public float floatDuration = 2f;

    [Header("Dialogue Interaction")]
    public string playerTag = "Player";
    public string[] greetings;
    public AudioClip[] greetingVoiceLines;
    public string[] combatHelp;
    public AudioClip[] combatHelpVoiceLines;

    private NavMeshAgent agent;
    private float attackCooldown;
    private GameObject currentWeapon;
    private GameObject currentArmor;
    private Transform currentTarget;
    private Animator animator;

    void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
        animator = GetComponent<Animator>();
    }

    void Start()
    {
        EquipItems();
        ReturnToPost();
    }

    void Update()
    {
        if (currentTarget != null)
        {
            float distance = Vector3.Distance(transform.position, currentTarget.position);
            if (distance > chaseRange)
            {
                ReturnToPost();
            }
            else if (distance <= attackRange && attackCooldown <= 0f)
            {
                Attack();
            }
            else if (distance <= chaseRange)
            {
                ChaseTarget(currentTarget);
            }
        }
        else
        {
            LookForTargets();
        }

        attackCooldown -= Time.deltaTime;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag(playerTag))
        {
            GreetPlayer();
        }
        else if (other.CompareTag(enemyTag))
        {
            OfferCombatHelp();
            SetTarget(other.transform);
        }
    }

    void EquipItems()
    {
        if (weaponPrefab)
            currentWeapon = Instantiate(weaponPrefab, transform);
        if (armorPrefab)
            currentArmor = Instantiate(armorPrefab, transform);
    }

    void LookForTargets()
    {
        Collider[] targetsInViewRadius = Physics.OverlapSphere(transform.position, viewDistance, visionLayerMask);
        foreach (Collider collider in targetsInViewRadius)
        {
            Transform target = collider.transform;
            if (target.CompareTag(enemyTag) && CanSeeTarget(target))
            {
                SetTarget(target);
                break;
            }
        }
    }

    bool CanSeeTarget(Transform target)
    {
        Vector3 dirToTarget = (target.position - transform.position).normalized;
        if (Vector3.Angle(transform.forward, dirToTarget) < viewAngle / 2)
        {
            RaycastHit hit;
            if (!Physics.Raycast(transform.position, dirToTarget, out hit, viewDistance))
            {
                if (hit.transform == target)
                {
                    return true;
                }
            }
        }
        return false;
    }

    void ChaseTarget(Transform target)
    {
        animator.SetBool("IsChasing", true);
        agent.SetDestination(target.position);
    }

    void Attack()
    {
        animator.SetTrigger("Attack");
        if (currentTarget != null)
        {
            Enemy enemyComponent = currentTarget.GetComponent<Enemy>();
            if (enemyComponent != null)
            {
                enemyComponent.TakeDamage(attackDamage);
            }
        }
        attackCooldown = 1f / attackRate;
    }

    public void TakeDamage(float damage)
    {
        health -= damage;
        if (health <= 0f)
        {
            Die();
        }
    }

    void Die()
    {
        animator.SetTrigger("Die");
        Destroy(gameObject);
    }

    void ReturnToPost()
    {
        currentTarget = null;
        animator.SetBool("IsChasing", false);
        agent.SetDestination(guardPost.position);
    }

    public void Speak(string text, AudioClip clip)
    {
        ShowFloatingText(text);
        PlayVoiceLine(clip);
    }

    void ShowFloatingText(string textToShow)
    {
        var dialogueInstance = Instantiate(dialogueTextPrefab, dialogueSpawnPoint.position, Quaternion.identity, worldCanvas.transform);
        var textComponent = dialogueInstance.GetComponent<Text>();
        textComponent.text = textToShow;
        StartCoroutine(FloatAndFadeText(textComponent, floatDuration));
    }

    IEnumerator FloatAndFadeText(Text textComponent, float duration)
    {
        float elapsedTime = 0f;
        Vector3 startPosition = textComponent.transform.position;
        Color startColor = textComponent.color;

        while (elapsedTime < duration)
        {
            float newY = Mathf.Lerp(startPosition.y, startPosition.y + floatUpDistance, (elapsedTime / duration));
            textComponent.transform.position = new Vector3(startPosition.x, newY, startPosition.z);
            textComponent.color = new Color(startColor.r, startColor.g, startColor.b, 1f - (elapsedTime / duration));

            elapsedTime += Time.deltaTime;
            yield return null;
        }

        Destroy(textComponent.gameObject);
    }

    void PlayVoiceLine(AudioClip clip)
    {
        if (clip != null)
        {
            AudioSource.PlayClipAtPoint(clip, transform.position);
        }
    }

    void GreetPlayer()
    {
        int index = Random.Range(0, greetings.Length);
        Speak(greetings[index], greetingVoiceLines.Length > index ? greetingVoiceLines[index] : null);
    }

    void OfferCombatHelp()
    {
        int index = Random.Range(0, combatHelp.Length);
        Speak(combatHelp[index], combatHelpVoiceLines.Length > index ? combatHelpVoiceLines[index] : null);
    }

    void SetTarget(Transform target)
    {
        currentTarget = target;
        agent.SetDestination(target.position);
    }

    void OnDrawGizmosSelected()
    {
        // Visualize attack range
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, attackRange);
        // Visualize chase range
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position, chaseRange);
        // Visualize view distance and angle
        Gizmos.color = Color.white;
        Gizmos.DrawWireSphere(transform.position, viewDistance);
        Vector3 rightBoundary = Quaternion.Euler(0, viewAngle / 2, 0) * transform.forward * viewDistance;
        Vector3 leftBoundary = Quaternion.Euler(0, -viewAngle / 2, 0) * transform.forward * viewDistance;
        Gizmos.DrawLine(transform.position, transform.position + rightBoundary);
        Gizmos.DrawLine(transform.position, transform.position + leftBoundary);
    }
}
