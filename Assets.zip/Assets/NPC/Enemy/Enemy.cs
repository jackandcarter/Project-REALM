using UnityEngine;
using UnityEngine.AI;

public class Enemy : MonoBehaviour
{
    [Header("Sensory Properties")]
    public float viewDistance = 15f;
    public float viewAngle = 110f;
    public float hearingRange = 15f;
    public LayerMask targetLayer; // Layer on which the enemy will detect targets (players)
    public LayerMask obstacleLayer; // Layer on which the enemy will detect obstacles

    [Header("Patrol Properties")]
    public Transform[] patrolPoints;
    private int currentPatrolIndex;

    [Header("Chase Properties")]
    public float chaseSpeed = 4f;
    public float patrolSpeed = 2f;
    public float chaseTriggerDistance = 10f; // When to start chasing the player

    [Header("Attack Properties")]
    public float attackRange = 2f;
    public float attackDamage = 10f;
    public float timeBetweenAttacks = 1f;

    private NavMeshAgent agent;
    private float attackTimer;
    private Transform currentTarget;

    private enum State
    {
        Patrolling,
        Chasing,
        Attacking
    }

    private State currentState;

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        currentPatrolIndex = 0;
        currentState = State.Patrolling;
        attackTimer = timeBetweenAttacks;
        
        // Start with the first patrol point
        if (patrolPoints.Length > 0)
        {
            agent.destination = patrolPoints[currentPatrolIndex].position;
        }
    }

    void Update()
    {
        // Handle attack cooldown
        attackTimer -= Time.deltaTime;

        switch (currentState)
        {
            case State.Patrolling:
                Patrol();
                break;
            case State.Chasing:
                Chase();
                break;
            case State.Attacking:
                if (currentTarget != null)
                {
                    Attack();
                }
                break;
        }

        // Continuously detect for players
        if (currentState != State.Attacking)
        {
            DetectPlayers();
        }
    }

    void Patrol()
    {
        // If we've reached the current patrol point, move to the next one
        if (!agent.pathPending && agent.remainingDistance < 0.5f)
        {
            currentPatrolIndex = (currentPatrolIndex + 1) % patrolPoints.Length;
            agent.destination = patrolPoints[currentPatrolIndex].position;
        }
        agent.speed = patrolSpeed;
    }

    void Chase()
    {
        if (currentTarget != null)
        {
            agent.speed = chaseSpeed;
            agent.destination = currentTarget.position;
            if (Vector3.Distance(transform.position, currentTarget.position) > chaseTriggerDistance)
            {
                // Lose sight of the player, return to patrol
                currentTarget = null;
                currentState = State.Patrolling;
            }
            else if (Vector3.Distance(transform.position, currentTarget.position) <= attackRange && attackTimer <= 0f)
            {
                // Close enough to attack
                currentState = State.Attacking;
            }
        }
    }

    void Attack()
    {
        if (currentTarget != null)
        {
            // Ensure the enemy is close enough to attack the player
            if (Vector3.Distance(transform.position, currentTarget.position) <= attackRange)
            {
                // Attack the player
                // This would involve an animation and possibly calling a TakeDamage method on the player
                // PlayerHealth playerHealth = currentTarget.GetComponent<PlayerHealth>();
                // if (playerHealth != null) { playerHealth.TakeDamage(attackDamage); }
                Debug.Log("Attack the player!");

                // Reset the attack timer
                attackTimer = timeBetweenAttacks;
            }
            else
            {
                // Player is out of range, chase again
                currentState = State.Chasing;
            }
        }
    }

    void DetectPlayers()
    {
        // Look for the closest player to chase within the view distance and angle
        Collider[] targetsInViewRadius = Physics.OverlapSphere(transform.position, viewDistance, targetLayer);
        foreach (Collider potentialTarget in targetsInViewRadius)
        {
            Transform targetTransform = potentialTarget.transform;
            Vector3 dirToTarget = (targetTransform.position - transform.position).normalized;
            if (Vector3.Angle(transform.forward, dirToTarget) < viewAngle / 2)
            {
                float distToTarget = Vector3.Distance(transform.position, targetTransform.position);
                if (!Physics.Raycast(transform.position, dirToTarget, distToTarget, obstacleLayer))
                {
                    // Target in sight and within hearing range
                    if (distToTarget < hearingRange)
                    {
                        currentTarget = targetTransform;
                        currentState = State.Chasing;
                        break; // Only chase the closest player
                    }
                }
            }
        }
    }

    public void TakeDamage(float amount)
    {
        attackDamage -= amount;
        if (attackDamage <= 0)
        {
            Die();
        }
    }

    void Die()
    {
        // Handle the death here: disable the enemy, play animation, etc.
        Debug.Log("Enemy is dead!");
        Destroy(gameObject);
    }
}
