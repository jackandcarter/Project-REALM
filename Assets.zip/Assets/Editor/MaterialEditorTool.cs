using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using System.IO;

public class MaterialBuilderTool : EditorWindow
{
    public enum MaterialType
    {
        BaseMaterial,
        BuildingMaterial,
        CosmeticMaterial,
        CraftingMaterial,
        NaturalResource
    }

    [System.Serializable]
    public class CustomMaterial : ScriptableObject
    {
        public string MaterialName;
        public MaterialType MaterialType;
        public int MaxStackQuantity;
        public float SalePrice;
        public int Rarity;
    }

    private string newMaterialName = "";
    private MaterialType selectedMaterialType = MaterialType.BaseMaterial;
    private int maxStackQuantity = 1;
    private float salePrice = 0.0f;
    private int rarity = 1;

    private Vector2 leftListScrollPosition;
    private List<MaterialType> materialTypes = new List<MaterialType>();

    private const float materialTypeColumnWidth = 200f;

    [MenuItem("Custom Tools/Material Builder")]
    public static void ShowWindow()
    {
        EditorWindow.GetWindow(typeof(MaterialBuilderTool));
    }

    private void OnEnable()
    {
        CheckAndCreateFolders();
        LoadMaterialTypes();
    }

    private void OnGUI()
    {
        GUILayout.BeginHorizontal();

        // Left List View
        GUILayout.BeginVertical(GUILayout.Width(materialTypeColumnWidth));
        leftListScrollPosition = GUILayout.BeginScrollView(leftListScrollPosition, GUILayout.ExpandHeight(true));

        foreach (var type in materialTypes)
        {
            if (GUILayout.Button(type.ToString()))
            {
                // Handle loading materials of the selected type
                LoadMaterialsOfType(type);
            }
        }

        GUILayout.EndScrollView();
        GUILayout.EndVertical();

        // Main Content
        GUILayout.BeginVertical();

        // New Material Form
        GUILayout.BeginHorizontal();
        GUILayout.Label("New Material Name:", GUILayout.Width(120));
        newMaterialName = GUILayout.TextField(newMaterialName, GUILayout.Width(200));
        GUILayout.EndHorizontal();

        selectedMaterialType = (MaterialType)EditorGUILayout.EnumPopup("Material Type:", selectedMaterialType);
        maxStackQuantity = EditorGUILayout.IntField("Max Stack Quantity:", maxStackQuantity);
        salePrice = EditorGUILayout.FloatField("Sale Price:", salePrice);
        rarity = EditorGUILayout.IntField("Rarity:", rarity);

        // Create Material Button
        if (GUILayout.Button("Create Material", GUILayout.Height(30)))
        {
            CreateNewMaterial();
        }

        GUILayout.EndVertical();

        GUILayout.EndHorizontal();
    }

    private void LoadMaterialTypes()
    {
        // Load material types from the Assets folder
        string[] folders = { "BaseMaterial", "BuildingMaterial", "CosmeticMaterial", "CraftingMaterial", "NaturalResource" };

        materialTypes.Clear();

        foreach (var folder in folders)
        {
            string path = "Assets/" + folder;

            if (AssetDatabase.IsValidFolder(path))
            {
                MaterialType type;
                if (System.Enum.TryParse(folder, out type))
                {
                    materialTypes.Add(type);
                }
                else
                {
                    Debug.LogError($"Failed to parse folder name '{folder}' to MaterialType enum.");
                }
            }
        }
    }

    private void CheckAndCreateFolders()
    {
        // Check and create folders in the Assets directory
        string[] folders = { "BaseMaterial", "BuildingMaterial", "CosmeticMaterial", "CraftingMaterial", "NaturalResource" };

        foreach (var folder in folders)
        {
            string path = "Assets/" + folder;

            if (!AssetDatabase.IsValidFolder(path))
            {
                AssetDatabase.CreateFolder("Assets", folder);
            }
        }
    }

    private void LoadMaterialsOfType(MaterialType type)
    {
        // Load materials of the specified type
        string folderPath = "Assets/" + type.ToString();

        if (AssetDatabase.IsValidFolder(folderPath))
        {
            string[] materialFiles = Directory.GetFiles(folderPath, "*.asset");

            // Handle loading and displaying materials
        }
    }

    private void CreateNewMaterial()
    {
        // Validate input fields
        if (string.IsNullOrEmpty(newMaterialName))
        {
            Debug.LogError("Material name cannot be empty.");
            return;
        }

        // Create a new material
        CustomMaterial newMaterial = ScriptableObject.CreateInstance<CustomMaterial>();
        newMaterial.MaterialName = newMaterialName;
        newMaterial.MaterialType = selectedMaterialType;
        newMaterial.MaxStackQuantity = maxStackQuantity;
        newMaterial.SalePrice = salePrice;
        newMaterial.Rarity = rarity;

        // Save the material to the respective folder
        string folderPath = "Assets/" + selectedMaterialType.ToString();
        string assetPath = folderPath + "/" + newMaterialName + ".asset";

        // Ensure the directory exists before creating the asset
        if (!Directory.Exists(folderPath))
        {
            Directory.CreateDirectory(folderPath);
        }

        AssetDatabase.CreateAsset(newMaterial, assetPath);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();

        // Clear the form for creating a new material
        newMaterialName = "";
        maxStackQuantity = 1;
        salePrice = 0.0f;
        rarity = 1;

        // Reload materials of the selected type
        LoadMaterialsOfType(selectedMaterialType);
    }
}
