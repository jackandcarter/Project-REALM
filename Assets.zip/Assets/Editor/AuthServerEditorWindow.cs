using UnityEngine;
using UnityEditor;
using UnityEngine.Networking;

public class AuthServerWindow : EditorWindow
{
    private string usernameInput = "";
    private string passwordInput = "";
    private string resultText = "";

    [MenuItem("Window/Auth Server Window")]
    public static void ShowWindow()
    {
        GetWindow<AuthServerWindow>("Auth Server");
    }

    private void OnGUI()
    {
        GUILayout.Label("Auth Server", EditorStyles.boldLabel);

        // Input fields for username and password
        usernameInput = EditorGUILayout.TextField("Username:", usernameInput);
        passwordInput = EditorGUILayout.PasswordField("Password:", passwordInput);

        // Buttons for common server operations
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Create User Account"))
        {
            CreateAccount(usernameInput, passwordInput);
        }
        // Add more buttons for other operations as needed
        GUILayout.EndHorizontal();

        // Button to restart the server
        if (GUILayout.Button("Restart Server"))
        {
            RestartServer();
        }

        // Button to send command to the server
        GUILayout.Space(10f);
        if (GUILayout.Button("Send Command"))
        {
            SendCommandToServer("custom_command");
        }

        // Display result from the server
        EditorGUILayout.Space();
        EditorGUILayout.LabelField("Server Response:");
        EditorGUILayout.TextArea(resultText, GUILayout.Height(80));
    }

   private void CreateAccount(string username, string password)
{
    string command = $"create_user_account?username={UnityWebRequest.EscapeURL(username)}&password={UnityWebRequest.EscapeURL(password)}";
    SendCommandToServer(command);
}


    private void SendCommandToServer(string command)
    {
        string serverURL = "http://localhost:5000/command";

        using (UnityWebRequest www = UnityWebRequest.PostWwwForm(serverURL, "POST"))
        {
            www.SetRequestHeader("command", command);

            www.SendWebRequest();

            while (!www.isDone) { }

            if (www.result != UnityWebRequest.Result.Success)
            {
                resultText = "Error: " + www.error;
            }
            else
            {
                resultText = www.downloadHandler.text;
            }
        }
    }

    private void RestartServer()
    {
        // Implement logic to restart the server
        // You might use a separate command or method to restart the server
        // For simplicity, this example displays a message
        resultText = "Server Restarted!";
    }
}
