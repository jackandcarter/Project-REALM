namespace Layer.Editor
{
public class Style
{
  public string id;
  public string name;

  public Style(dynamic style)
  {
    this.id = style.id;
    this.name = style.name;
  }
}
}